import Foundation
import simd

/// Recognizes an intentional dwell near any existing point in the active constellation.
struct ExistingPointConnectionDetector: Sendable {
    struct Target: Equatable, Sendable {
        let nodeID: Int
        let position: SIMD3<Float>
        let isAlreadyConnected: Bool
    }

    enum Phase: Equatable, Sendable {
        case idle
        case available
        case dwelling
    }

    struct Snapshot: Equatable, Sendable {
        let phase: Phase
        let target: Target?
        let progress: Float
        let didCommit: Bool
    }

    let dwellDuration: TimeInterval
    let snapDistance: Float
    let releaseDistance: Float
    let departureDistance: Float

    private var hasDepartedActivePoint = false
    private var lockedTarget: Target?
    private var startedAt: TimeInterval?

    init(
        dwellDuration: TimeInterval = ConstellationConfiguration.standard.dwellDuration,
        snapDistance: Float = ConstellationConfiguration.standard.connectionSnapDistance,
        releaseDistance: Float = ConstellationConfiguration.standard.connectionReleaseDistance,
        departureDistance: Float = ConstellationConfiguration.standard.rearmDistance
    ) {
        precondition(dwellDuration > 0)
        precondition(snapDistance > 0)
        precondition(releaseDistance >= snapDistance)
        precondition(departureDistance > 0)
        self.dwellDuration = dwellDuration
        self.snapDistance = snapDistance
        self.releaseDistance = releaseDistance
        self.departureDistance = departureDistance
    }

    mutating func update(
        position: SIMD3<Float>,
        activePoint: SIMD3<Float>?,
        targets: [Target],
        at timestamp: TimeInterval
    ) -> Snapshot {
        guard let activePoint,
              !targets.isEmpty,
              position.hasFiniteComponents,
              activePoint.hasFiniteComponents,
              targets.allSatisfy({ $0.position.hasFiniteComponents }),
              timestamp.isFinite else {
            reset()
            return idleSnapshot
        }

        if !hasDepartedActivePoint {
            hasDepartedActivePoint = simd_distance(position, activePoint) >= departureDistance
            guard hasDepartedActivePoint else {
                return availableSnapshot
            }
        }

        if let lockedTarget {
            guard targets.contains(where: { $0.nodeID == lockedTarget.nodeID }),
                  simd_distance(position, lockedTarget.position) <= releaseDistance,
                  let startedAt else {
                cancelCandidate()
                return availableSnapshot
            }

            let elapsed = max(0, timestamp - startedAt)
            let progress = Float(min(1, elapsed / dwellDuration))
            let didCommit = elapsed + 1e-9 >= dwellDuration

            if didCommit {
                cancelCandidate()
                hasDepartedActivePoint = false
            }

            return Snapshot(
                phase: .dwelling,
                target: lockedTarget,
                progress: progress,
                didCommit: didCommit
            )
        }

        guard let nearestTarget = targets
            .map({ ($0, simd_distance(position, $0.position)) })
            .filter({ $0.1 <= snapDistance })
            .min(by: { $0.1 < $1.1 })?.0 else {
            return availableSnapshot
        }

        lockedTarget = nearestTarget
        startedAt = timestamp
        return Snapshot(
            phase: .dwelling,
            target: nearestTarget,
            progress: 0,
            didCommit: false
        )
    }

    mutating func pointCommitted() {
        hasDepartedActivePoint = false
        cancelCandidate()
    }

    mutating func trackingLost() {
        hasDepartedActivePoint = false
        cancelCandidate()
    }

    mutating func reset() {
        hasDepartedActivePoint = false
        cancelCandidate()
    }

    private mutating func cancelCandidate() {
        lockedTarget = nil
        startedAt = nil
    }

    private var availableSnapshot: Snapshot {
        Snapshot(phase: .available, target: nil, progress: 0, didCommit: false)
    }

    private var idleSnapshot: Snapshot {
        Snapshot(phase: .idle, target: nil, progress: 0, didCommit: false)
    }
}
